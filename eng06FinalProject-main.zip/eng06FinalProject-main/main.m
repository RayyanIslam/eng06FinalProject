deck = Deck;
community = Community;

p1 = Play(deck, 300);
p2 = Play(deck, 300);

for i = 1<=5
    community.addCard(deck.drawCard);
end

p1.raise(100);
p1.Balance

handp1 = Hand(p1.Pocket.Cards, community.Cards);

handp1.isStraight






