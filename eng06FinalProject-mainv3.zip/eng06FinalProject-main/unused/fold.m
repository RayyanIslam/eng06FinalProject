function [deck] = fold(cards)
%Shuffles Cards
deck = shuffle(cards,2)
end