classdef Play < handle
    properties
        Balance
        Pocket
        Status
    end

    methods 
        function play = Play(deck, balance)
            play.Balance = Wallet(balance);
            play.Pocket = Pocket(deck.drawCard(), deck.drawCard());
            play.Status = 1;
            
        end


        function play = raise(play, amount)
            play.Balance.Amount = play.Balance.Amount - amount;
        end
        function play = call(play, amount)
            play.Balance.Amount = play.Balance.Amount - amount;
        end
        function play = fold(play)
            play.Status = 0;
        end
    end
end