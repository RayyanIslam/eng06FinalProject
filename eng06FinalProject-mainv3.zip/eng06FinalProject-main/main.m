deck = Deck;
community = Community;

p1 = Play(deck, 300);
p2 = Play(deck, 300);

for i = 1:5
    community.addCard(deck.drawCard);
end

%p1.Pocket.Cards.Value
[card1v, card2v, card3v, card4v, card5v] = community.Cards.Value;
[card1s, card2s, card3s, card4s, card5s] = community.Cards.Suit;

cc1filename = convertStringsToChars(strcat(card1v,card1s,'s.png'));

p2.raise(20);
p2.raise(100);
p2.raise(20);

[pcard1v, pcard2v] = p1.Pocket.Cards.Value;
[pcard1s, pcard2s] = p1.Pocket.Cards.Suit;






%p1.raise(100);
%p1.Balance

%handp1 = Hand(p1.Pocket.Cards, community.Cards);

%handp1.isStraight






